[https://histre2022.markbase.xyz/Lois%20Lane]: URL

# Vermont Web Links

- [VT Parcel Viewer](https://maps.vcgi.vermont.gov/ParcelViewer/)
- [Vermont Natural Resources Atlas](https://maps.vermont.gov/ANR/Html5Viewer/index.html?viewer=ANR_ANRAv2.ANRA5)
- [Arlington Land Records](https://arlington.lr-1.com/)

---

# [0 Lois Ln, Arlington, VT 05250 | MLS# 4930197 | Redfin](https://www.redfin.com/VT/Arlington/Lois-Ln-05250/home/91187680)

[Histre Permalink](https://histre.com/notes/sdreinhardt/g0k4x8oh/)


SPAN: 015-005-10487


7.49 acres; $152,000


Lois Ln is 1 parcel North of 1421 OLD WEST ROAD, ARLINGTON, VT, 05250

**Listing Notes:** Don't let this one get away. ! Bring Your Architect/Builder, There Is Still Time To Get Your Foundation In! Seven plus (7.49) very special acres comprised of three lots located on Lois Lane, a private dead end road off of Old West Road in the Historic Town of Arlington. The meandering driveway is already cut in and ready to lead you to your new homesite. As you head into Lois Lane lot #3 is located on your left and is suitable for a garage/studio/workshop with the possibility of an apartment above. The homesite on lots #4 & 5 is located privately at the end of Lois Lane. The existing mountain views are ready to be transformed into dramatic long views after a bit of tree thinning. State waste water permits are in place for your four bedroom home. This kind of bucolic setting is getting harder to find. .. make it yours!

## Notes

- Poor T-Mo signal (faded in and out while we were on the building envelope)
- We found 4 or more perforated 4" PVC pipes coming out of the ground in the way-low section
- Cleared field on the property to the North
- Nice improvements (road and building envelope)
- Building Envelope  - [On GoogleMaps](https://goo.gl/maps/VxvMMkUaSCXkXy6n7)
    - SE ///recruited.fragmented.soften
    - NE ///fists.reforms.conceals
    - NW ///unbalanced.velocities.twitches
    - SW ///environment.gentler.kinder


![Parcel Viewer Image](https://i.imgur.com/HglXwbA.jpg)

![](https://firebasestorage.googleapis.com/v0/b/fleetingnotes-22f77.appspot.com/o/bf90e120-4457-11ed-af5e-b3d9bb7b9163%2F20221004224509_p.jpg?alt=media&token=d91c2d43-3aad-448e-b9ff-9eedc8e42407)

![topo](https://firebasestorage.googleapis.com/v0/b/fleetingnotes-22f77.appspot.com/o/38ed79d0-4687-11ed-aaf6-1fc6a26fb8df%2Fsignal-2022-10-07-19-21-58-802.jpg?alt=media&token=768387b0-a70b-4289-87f0-49e251966a94)

![Dimension Detail](https://i.imgur.com/ZGIFMEZ.jpg)

---

## Wastewater Sytem and Potable Water Supply Permit

![Wastewater System Permit pg1](https://arlington.lr-1.com/img/book0166page0197-0198cornell%20%20gavin%20w-ve-1.jpg)

![Wastewater System Permit pg2](https://arlington.lr-1.com/img/book0166page0197-0198cornell%20%20gavin%20w-ve-2.jpg)

![Wastewater System Permit pg3](https://arlington.lr-1.com/img/book0166page0197-0198cornell%20%20gavin%20w-ve-3.jpg "Wastewater System Permit pg3")


---

## Warranty Deed

Cornell, Gavin

![Warranty Deep pg1](https://arlington.lr-1.com/img/book0165page0418-0419intrilligator%20llc-c-1.jpg)
![Warranty Deep pg2](https://arlington.lr-1.com/img/book0165page0418-0419intrilligator%20llc-c-2.jpg)
![Warranty Deep pg3](https://arlington.lr-1.com/img/book0165page0418-0419intrilligator%20llc-c-3.jpg)

![Warranty Deep pg4](https://arlington.lr-1.com/img/book0165page0418-0419intrilligator%20llc-c-4.jpg)

![Warranty Deep pg5](https://arlington.lr-1.com/img/book0165page0418-0419intrilligator%20llc-c-5.jpg)

---

# Lot #1 Warranty Deed

PETERS, SANDRA L TRUST  
SPAN: 015-005-10552

![](https://arlington.lr-1.com/img/0151_0309_0310-1.jpg)

![](https://arlington.lr-1.com/img/0151_0309_0310-2.jpg)

---

# Lot #2 Warranty Deed

CAVANAGH, MICHAEL  
SPAN: 015-005-10191

![](https://arlington.lr-1.com/img/0062_0320_0321-1.jpg)

![](https://arlington.lr-1.com/img/0062_0320_0321-2.jpg)

---

# SUBDIVISION PERMIT

![](https://arlington.lr-1.com/img/0063_0033_0035-1.jpg)


![](https://arlington.lr-1.com/img/0063_0033_0035-2.jpg)


![](https://arlington.lr-1.com/img/0063_0033_0035-3.jpg)

---

# Easement

![](https://arlington.lr-1.com/img/0062_0318_0318-1.jpg)

![[Site plan with building area highlighted.pdf]]